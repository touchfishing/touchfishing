from django.apps import AppConfig


class MallConfig(AppConfig):
    name = 'mall'
